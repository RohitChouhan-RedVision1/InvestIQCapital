import * as React from 'react';

export const EmailTemplate = ({ firstName }) => (
    <div>
        <h1>Welcome, {firstName}!</h1>
    </div>
);
