import React from 'react'

const page = () => {
    return (
        <div className='bg-red-600'>page</div>
    )
}

export default page