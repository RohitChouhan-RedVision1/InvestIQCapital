/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["res.cloudinary.com", "wealthelite.in","redvisionweb.com"],
    },
};

export default nextConfig;
